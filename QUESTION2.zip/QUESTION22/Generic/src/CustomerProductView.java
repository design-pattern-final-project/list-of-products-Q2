
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Engineer Melkam Beyu
 */
public class CustomerProductView implements DisplayAPI {
   

//    @Override
//    public void displayProduct() {
//         try {
//             gui gui =new gui();
//             gui.Show_product_In_Table();
////            
////        }
//         } catch (SQLException ex) {
//             Logger.getLogger(CustomerProductView.class.getName()).log(Level.SEVERE, null, ex);
//         }
//    }
     
    public  ArrayList<Product>displayProduct(){
        Connection con;
        PreparedStatement st;
        ResultSet rs;
        
        
        
        
        ArrayList <Product>list=new ArrayList();
        Database db=new Database();
        con=db.getConnection();
        String query="SELECT * FROM product_list";
        try{
            st=con.prepareStatement(query);
            rs=st.executeQuery();
            Product product;
            while(rs.next()){
                product=new Product(rs.getString("product_name"));
              list.add(product);
                //Arrays.sort(list.toArray(arrays))
              
                
            }
            list.sort(new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Product product1=(Product) o1;
                Product product2=(Product)o2;
                
                return product1.getProductname().compareTo(product2.getProductname());
                
            }
        });
        }catch(Exception e){
            System.err.println(e);
        }
        
        
        
   
        return list;
        
    }
    
    
    

    
    }
    

