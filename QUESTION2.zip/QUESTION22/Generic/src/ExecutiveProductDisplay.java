
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Engineer Melkam Beyu
 */
public class ExecutiveProductDisplay implements DisplayAPI{
    private javax.swing.JTable jtbl1;
    

//    @Override
//    public void displayProduct() {
//        gui gui;
//        try {
//            gui = new gui();
//            gui.show_excutive_view();
//        } catch (SQLException ex) {
//            Logger.getLogger(ExecutiveProductDisplay.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        
//        
//    }
//    
      public ArrayList< Shipped_product> displayProduct(){
        Connection con=null;
        PreparedStatement st=null;
        ResultSet rs=null;
        
        
        ArrayList<Shipped_product>productlist=new ArrayList<Shipped_product>();
        Database db=new Database();
      con= db.getConnection();
        
        String query = "SELECT * FROM shipped_product";
        
        
        
        try{
           st=con.prepareStatement(query);
          rs=st.executeQuery();
           // rs=st.
             Shipped_product product; 
            while(rs.next()){
                product=new Shipped_product(rs.getString("product_name"),rs.getInt("price"),rs.getString("quality"),rs.getInt("quantity"));
                productlist.add(product);
            }
//              productlist.add(product);
            
        }catch(Exception e){
            System.err.println(e);
        }
        return productlist;
        
    } 

    }
   
    
    
    
    
