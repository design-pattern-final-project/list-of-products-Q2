/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Engineer Melkam Beyu
 */
public class Product {
    String product_name;
    int price;
    int  date;
    String quality;
    int quantity;

    Product(String product_name) { 
         //To change body of generated methods, choose Tools | Templates.
       // this.date=date;
        this.product_name=product_name;
       // this.quality=quality;z
       // this.sale=sale;
    }

    
    
    public String getProductname(){
        return product_name;
    }
    public void setProducname(String product_name){
        this.product_name=product_name;
    }
    
    public int getPrice(){
        return price;
    }
    public void setPrice(int price){
        this.price=price;
    }
    
    public int getDate(){
        return date;
    }
    public void setDate(int date){
        this.date=date;;
    }
    
    public String getQuality(){
        return quality;
    }
    public void setQuality(String quality){
        this.quality=quality;
    }
    
    public void setQuantity(int quantity){
        this.quantity=quantity;
    }
    
    public int getQuantity(){
        return quantity;
    }
    
}
