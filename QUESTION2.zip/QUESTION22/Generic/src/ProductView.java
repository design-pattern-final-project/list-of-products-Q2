
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Engineer Melkam Beyu
 */
public class ProductView<E> extends View{
    
    String product_name;
    int sale;
    int  date;
    String quality;
    

    public ProductView(DisplayAPI displayApi) {
        super(displayApi);
    }
    
    
   

    

    @Override
    public ArrayList<E> display() {
        return displayApi.displayProduct();

    }
    
    
}
